//
//  LocationPic.swift
//  BAPMobile
//
//  Created by Administrator on 02/06/2022.
//

import Foundation
import UIKit

class LocationPic: UIView {
    
    @IBOutlet weak var parrentView: UIView!
    
    @IBOutlet weak var lblAddress: UILabel!

    @IBOutlet weak var iconGps: UIImageView!
    @IBOutlet weak var iconMap: UIImageView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }
    
    func commonInit(){
        Bundle.main.loadNibNamed("LocationPic", owner: self, options: nil)
        addSubview(parrentView)
        parrentView.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        parrentView.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        
        parrentView.topAnchor.constraint(equalTo: self.topAnchor).isActive = true
        parrentView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
        

        
       
    }
   
    func setupView(address: String?){
        lblAddress.text = address
    }
}
