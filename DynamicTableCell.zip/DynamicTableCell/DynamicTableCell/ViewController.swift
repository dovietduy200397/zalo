//
//  ViewController.swift
//  DynamicTableCell
//
//  Created by Do Duy on 14/08/2022.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return namesArray.count
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AppCell", for: indexPath) as! AppCell
        cell.setup(names: namesArray[indexPath.row])
        cell.labelTitle.text = labelsArray[indexPath.row]
        return cell
    }
    
    @IBOutlet weak var outerTableView: UITableView!
    
    let data = [4, 5, 1, 3]
    var namesArray = [["ThljfdklsjfklsadjfklsdjfaklsdfThljfdklsjfklsadjfklsdjfaklsdfjklsdajfklsdjfklsajfklsadfjklsdjfjklsdajfklsdjfklsajfklsadfjklsdjf","b","c"],["d","e"],["f"],["g","h"],[],["j"]]
    var labelsArray = ["Thljfdklsjfklsadjfklsdjfaklsdfjklsdajfklsdjfklsajfklsadfjklsdjf", "sfs", "sdfdsfhjksehrejwkbdsihfiosdfiosdf", "đà", "sdfafssffsfsafsdfs", "dfas"]
    override func viewDidLoad() {
        super.viewDidLoad()
        outerTableView.delegate = self
        outerTableView.dataSource = self
        outerTableView.register(UINib(nibName: "AppCell", bundle: nil), forCellReuseIdentifier: "AppCell")
        outerTableView.estimatedRowHeight = 100
    }


}

