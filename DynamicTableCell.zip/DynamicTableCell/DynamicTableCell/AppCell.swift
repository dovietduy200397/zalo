//
//  AppCell.swift
//  DynamicTableCell
//
//  Created by Do Duy on 14/08/2022.
//

import UIKit

class AppCell: UITableViewCell {
    @IBOutlet weak var labelTitle: UILabel!
    @IBOutlet weak var stackView: UIStackView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        stackView.axis = .vertical
        stackView.distribution = .fill
        stackView.alignment = .fill
        stackView.spacing = 2
        stackView.translatesAutoresizingMaskIntoConstraints = false
    }
    
    func setup(names: [String]) {
        stackView.arrangedSubviews.forEach { stackView.removeArrangedSubview($0);$0.removeFromSuperview() }
        names.forEach { name in
            let redView = LocationPic()
            //redView.backgroundColor = .red
            redView.setupView(address: name)
//            redView.heightAnchor.constraint(greaterThanOrEqualToConstant: 44).isActive = true
            stackView.addArrangedSubview(redView)
        }
    }
}
